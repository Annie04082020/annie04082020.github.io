-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Aug  4 16:08:17 2026
-- Host        : DVSY-62334655 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/DVSY_62334655/Documents/vivado/001_projects/HDMI/HDMI.gen/sources_1/bd/design_1/ip/design_1_colorbar_0_0/design_1_colorbar_0_0_sim_netlist.vhdl
-- Design      : design_1_colorbar_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z010clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_colorbar_0_0_colorbar is
  port (
    rgb : out STD_LOGIC_VECTOR ( 2 downto 0 );
    x : in STD_LOGIC_VECTOR ( 10 downto 0 );
    active_video : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_colorbar_0_0_colorbar : entity is "colorbar";
end design_1_colorbar_0_0_colorbar;

architecture STRUCTURE of design_1_colorbar_0_0_colorbar is
  signal \rgb[16]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \rgb[8]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__0_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__0_n_1\ : STD_LOGIC;
  signal \x_color__0_carry__0_n_2\ : STD_LOGIC;
  signal \x_color__0_carry__0_n_3\ : STD_LOGIC;
  signal \x_color__0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__1_i_8_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__1_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__1_n_1\ : STD_LOGIC;
  signal \x_color__0_carry__1_n_2\ : STD_LOGIC;
  signal \x_color__0_carry__1_n_3\ : STD_LOGIC;
  signal \x_color__0_carry__1_n_4\ : STD_LOGIC;
  signal \x_color__0_carry__1_n_5\ : STD_LOGIC;
  signal \x_color__0_carry__1_n_6\ : STD_LOGIC;
  signal \x_color__0_carry__1_n_7\ : STD_LOGIC;
  signal \x_color__0_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \x_color__0_carry__2_n_7\ : STD_LOGIC;
  signal \x_color__0_carry_i_1_n_0\ : STD_LOGIC;
  signal \x_color__0_carry_i_2_n_0\ : STD_LOGIC;
  signal \x_color__0_carry_i_3_n_0\ : STD_LOGIC;
  signal \x_color__0_carry_i_4_n_0\ : STD_LOGIC;
  signal \x_color__0_carry_i_5_n_0\ : STD_LOGIC;
  signal \x_color__0_carry_i_6_n_0\ : STD_LOGIC;
  signal \x_color__0_carry_i_7_n_0\ : STD_LOGIC;
  signal \x_color__0_carry_n_0\ : STD_LOGIC;
  signal \x_color__0_carry_n_1\ : STD_LOGIC;
  signal \x_color__0_carry_n_2\ : STD_LOGIC;
  signal \x_color__0_carry_n_3\ : STD_LOGIC;
  signal \x_color__29_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \x_color__29_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \x_color__29_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \x_color__29_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \x_color__29_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \x_color__29_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \x_color__29_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \x_color__29_carry__0_n_1\ : STD_LOGIC;
  signal \x_color__29_carry__0_n_2\ : STD_LOGIC;
  signal \x_color__29_carry__0_n_3\ : STD_LOGIC;
  signal \x_color__29_carry_i_1_n_0\ : STD_LOGIC;
  signal \x_color__29_carry_i_2_n_0\ : STD_LOGIC;
  signal \x_color__29_carry_i_3_n_0\ : STD_LOGIC;
  signal \x_color__29_carry_i_4_n_0\ : STD_LOGIC;
  signal \x_color__29_carry_i_5_n_0\ : STD_LOGIC;
  signal \x_color__29_carry_i_6_n_0\ : STD_LOGIC;
  signal \x_color__29_carry_i_7_n_0\ : STD_LOGIC;
  signal \x_color__29_carry_n_0\ : STD_LOGIC;
  signal \x_color__29_carry_n_1\ : STD_LOGIC;
  signal \x_color__29_carry_n_2\ : STD_LOGIC;
  signal \x_color__29_carry_n_3\ : STD_LOGIC;
  signal \NLW_x_color__0_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_x_color__0_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_x_color__0_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_x_color__0_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_x_color__29_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_x_color__29_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_x_color__29_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \rgb[16]_INST_0_i_1\ : label is "soft_lutpair0";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \x_color__0_carry\ : label is 35;
  attribute ADDER_THRESHOLD of \x_color__0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \x_color__0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \x_color__0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \x_color__29_carry\ : label is 35;
  attribute ADDER_THRESHOLD of \x_color__29_carry__0\ : label is 35;
  attribute SOFT_HLUTNM of \x_color__29_carry__0_i_7\ : label is "soft_lutpair0";
  attribute HLUTNM : string;
  attribute HLUTNM of \x_color__29_carry_i_2\ : label is "lutpair0";
  attribute HLUTNM of \x_color__29_carry_i_6\ : label is "lutpair0";
begin
\rgb[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6566FFFF"
    )
        port map (
      I0 => \x_color__0_carry__1_n_7\,
      I1 => \x_color__29_carry__0_n_1\,
      I2 => x(10),
      I3 => \rgb[16]_INST_0_i_1_n_0\,
      I4 => active_video,
      O => rgb(0)
    );
\rgb[16]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55559959FFFFFFFF"
    )
        port map (
      I0 => \x_color__0_carry__1_n_6\,
      I1 => \x_color__0_carry__1_n_7\,
      I2 => \rgb[16]_INST_0_i_1_n_0\,
      I3 => x(10),
      I4 => \x_color__29_carry__0_n_1\,
      I5 => active_video,
      O => rgb(2)
    );
\rgb[16]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0F5FA080"
    )
        port map (
      I0 => \x_color__0_carry__1_n_5\,
      I1 => \x_color__0_carry__1_n_7\,
      I2 => \x_color__0_carry__1_n_4\,
      I3 => \x_color__0_carry__1_n_6\,
      I4 => \x_color__0_carry__2_n_7\,
      O => \rgb[16]_INST_0_i_1_n_0\
    );
\rgb[8]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55555595FFFFFFFF"
    )
        port map (
      I0 => \x_color__0_carry__1_n_5\,
      I1 => \x_color__0_carry__1_n_6\,
      I2 => \x_color__0_carry__1_n_7\,
      I3 => \rgb[8]_INST_0_i_1_n_0\,
      I4 => \x_color__29_carry__0_n_1\,
      I5 => active_video,
      O => rgb(1)
    );
\rgb[8]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005A4A2A2A"
    )
        port map (
      I0 => \x_color__0_carry__2_n_7\,
      I1 => \x_color__0_carry__1_n_6\,
      I2 => \x_color__0_carry__1_n_4\,
      I3 => \x_color__0_carry__1_n_7\,
      I4 => \x_color__0_carry__1_n_5\,
      I5 => x(10),
      O => \rgb[8]_INST_0_i_1_n_0\
    );
\x_color__0_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \x_color__0_carry_n_0\,
      CO(2) => \x_color__0_carry_n_1\,
      CO(1) => \x_color__0_carry_n_2\,
      CO(0) => \x_color__0_carry_n_3\,
      CYINIT => '0',
      DI(3) => \x_color__0_carry_i_1_n_0\,
      DI(2) => \x_color__0_carry_i_2_n_0\,
      DI(1) => \x_color__0_carry_i_3_n_0\,
      DI(0) => '0',
      O(3 downto 0) => \NLW_x_color__0_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \x_color__0_carry_i_4_n_0\,
      S(2) => \x_color__0_carry_i_5_n_0\,
      S(1) => \x_color__0_carry_i_6_n_0\,
      S(0) => \x_color__0_carry_i_7_n_0\
    );
\x_color__0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \x_color__0_carry_n_0\,
      CO(3) => \x_color__0_carry__0_n_0\,
      CO(2) => \x_color__0_carry__0_n_1\,
      CO(1) => \x_color__0_carry__0_n_2\,
      CO(0) => \x_color__0_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \x_color__0_carry__0_i_1_n_0\,
      DI(2) => \x_color__0_carry__0_i_2_n_0\,
      DI(1) => \x_color__0_carry__0_i_3_n_0\,
      DI(0) => \x_color__0_carry__0_i_4_n_0\,
      O(3 downto 0) => \NLW_x_color__0_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \x_color__0_carry__0_i_5_n_0\,
      S(2) => \x_color__0_carry__0_i_6_n_0\,
      S(1) => \x_color__0_carry__0_i_7_n_0\,
      S(0) => \x_color__0_carry__0_i_8_n_0\
    );
\x_color__0_carry__0_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => x(6),
      I1 => x(4),
      I2 => x(9),
      O => \x_color__0_carry__0_i_1_n_0\
    );
\x_color__0_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => x(5),
      I1 => x(3),
      I2 => x(8),
      O => \x_color__0_carry__0_i_2_n_0\
    );
\x_color__0_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => x(4),
      I1 => x(2),
      I2 => x(7),
      O => \x_color__0_carry__0_i_3_n_0\
    );
\x_color__0_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => x(3),
      I1 => x(1),
      I2 => x(6),
      O => \x_color__0_carry__0_i_4_n_0\
    );
\x_color__0_carry__0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => x(9),
      I1 => x(4),
      I2 => x(6),
      I3 => x(5),
      I4 => x(7),
      I5 => x(10),
      O => \x_color__0_carry__0_i_5_n_0\
    );
\x_color__0_carry__0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => x(8),
      I1 => x(3),
      I2 => x(5),
      I3 => x(4),
      I4 => x(6),
      I5 => x(9),
      O => \x_color__0_carry__0_i_6_n_0\
    );
\x_color__0_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => x(7),
      I1 => x(2),
      I2 => x(4),
      I3 => x(3),
      I4 => x(5),
      I5 => x(8),
      O => \x_color__0_carry__0_i_7_n_0\
    );
\x_color__0_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => x(6),
      I1 => x(1),
      I2 => x(3),
      I3 => x(2),
      I4 => x(4),
      I5 => x(7),
      O => \x_color__0_carry__0_i_8_n_0\
    );
\x_color__0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \x_color__0_carry__0_n_0\,
      CO(3) => \x_color__0_carry__1_n_0\,
      CO(2) => \x_color__0_carry__1_n_1\,
      CO(1) => \x_color__0_carry__1_n_2\,
      CO(0) => \x_color__0_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \x_color__0_carry__1_i_1_n_0\,
      DI(2) => \x_color__0_carry__1_i_2_n_0\,
      DI(1) => \x_color__0_carry__1_i_3_n_0\,
      DI(0) => \x_color__0_carry__1_i_4_n_0\,
      O(3) => \x_color__0_carry__1_n_4\,
      O(2) => \x_color__0_carry__1_n_5\,
      O(1) => \x_color__0_carry__1_n_6\,
      O(0) => \x_color__0_carry__1_n_7\,
      S(3) => \x_color__0_carry__1_i_5_n_0\,
      S(2) => \x_color__0_carry__1_i_6_n_0\,
      S(1) => \x_color__0_carry__1_i_7_n_0\,
      S(0) => \x_color__0_carry__1_i_8_n_0\
    );
\x_color__0_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => x(8),
      I1 => x(10),
      O => \x_color__0_carry__1_i_1_n_0\
    );
\x_color__0_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => x(7),
      I1 => x(9),
      O => \x_color__0_carry__1_i_2_n_0\
    );
\x_color__0_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => x(6),
      I1 => x(8),
      O => \x_color__0_carry__1_i_3_n_0\
    );
\x_color__0_carry__1_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => x(7),
      I1 => x(5),
      I2 => x(10),
      O => \x_color__0_carry__1_i_4_n_0\
    );
\x_color__0_carry__1_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4B"
    )
        port map (
      I0 => x(10),
      I1 => x(8),
      I2 => x(9),
      O => \x_color__0_carry__1_i_5_n_0\
    );
\x_color__0_carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => x(9),
      I1 => x(7),
      I2 => x(10),
      I3 => x(8),
      O => \x_color__0_carry__1_i_6_n_0\
    );
\x_color__0_carry__1_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => x(8),
      I1 => x(6),
      I2 => x(9),
      I3 => x(7),
      O => \x_color__0_carry__1_i_7_n_0\
    );
\x_color__0_carry__1_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"718E8E71"
    )
        port map (
      I0 => x(10),
      I1 => x(5),
      I2 => x(7),
      I3 => x(8),
      I4 => x(6),
      O => \x_color__0_carry__1_i_8_n_0\
    );
\x_color__0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \x_color__0_carry__1_n_0\,
      CO(3 downto 0) => \NLW_x_color__0_carry__2_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_x_color__0_carry__2_O_UNCONNECTED\(3 downto 1),
      O(0) => \x_color__0_carry__2_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \x_color__0_carry__2_i_1_n_0\
    );
\x_color__0_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => x(9),
      I1 => x(10),
      O => \x_color__0_carry__2_i_1_n_0\
    );
\x_color__0_carry_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => x(2),
      I1 => x(0),
      I2 => x(5),
      O => \x_color__0_carry_i_1_n_0\
    );
\x_color__0_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => x(0),
      I1 => x(2),
      I2 => x(5),
      O => \x_color__0_carry_i_2_n_0\
    );
\x_color__0_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => x(3),
      I1 => x(0),
      O => \x_color__0_carry_i_3_n_0\
    );
\x_color__0_carry_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => x(5),
      I1 => x(0),
      I2 => x(2),
      I3 => x(1),
      I4 => x(3),
      I5 => x(6),
      O => \x_color__0_carry_i_4_n_0\
    );
\x_color__0_carry_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69966969"
    )
        port map (
      I0 => x(0),
      I1 => x(2),
      I2 => x(5),
      I3 => x(1),
      I4 => x(4),
      O => \x_color__0_carry_i_5_n_0\
    );
\x_color__0_carry_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => x(0),
      I1 => x(3),
      I2 => x(1),
      I3 => x(4),
      O => \x_color__0_carry_i_6_n_0\
    );
\x_color__0_carry_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => x(3),
      I1 => x(0),
      O => \x_color__0_carry_i_7_n_0\
    );
\x_color__29_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \x_color__29_carry_n_0\,
      CO(2) => \x_color__29_carry_n_1\,
      CO(1) => \x_color__29_carry_n_2\,
      CO(0) => \x_color__29_carry_n_3\,
      CYINIT => '0',
      DI(3) => \x_color__29_carry_i_1_n_0\,
      DI(2) => \x_color__29_carry_i_2_n_0\,
      DI(1) => \x_color__29_carry_i_3_n_0\,
      DI(0) => '0',
      O(3 downto 0) => \NLW_x_color__29_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \x_color__29_carry_i_4_n_0\,
      S(2) => \x_color__29_carry_i_5_n_0\,
      S(1) => \x_color__29_carry_i_6_n_0\,
      S(0) => \x_color__29_carry_i_7_n_0\
    );
\x_color__29_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \x_color__29_carry_n_0\,
      CO(3) => \NLW_x_color__29_carry__0_CO_UNCONNECTED\(3),
      CO(2) => \x_color__29_carry__0_n_1\,
      CO(1) => \x_color__29_carry__0_n_2\,
      CO(0) => \x_color__29_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \x_color__29_carry__0_i_1_n_0\,
      DI(1) => \x_color__29_carry__0_i_2_n_0\,
      DI(0) => \x_color__29_carry__0_i_3_n_0\,
      O(3 downto 0) => \NLW_x_color__29_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \x_color__29_carry__0_i_4_n_0\,
      S(1) => \x_color__29_carry__0_i_5_n_0\,
      S(0) => \x_color__29_carry__0_i_6_n_0\
    );
\x_color__29_carry__0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000004642626A"
    )
        port map (
      I0 => \x_color__0_carry__1_n_4\,
      I1 => \x_color__0_carry__1_n_5\,
      I2 => \x_color__0_carry__2_n_7\,
      I3 => \x_color__0_carry__1_n_7\,
      I4 => \x_color__0_carry__1_n_6\,
      I5 => x(9),
      O => \x_color__29_carry__0_i_1_n_0\
    );
\x_color__29_carry__0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000009AA69666"
    )
        port map (
      I0 => \x_color__0_carry__2_n_7\,
      I1 => \x_color__0_carry__1_n_5\,
      I2 => \x_color__0_carry__1_n_6\,
      I3 => \x_color__0_carry__1_n_4\,
      I4 => \x_color__0_carry__1_n_7\,
      I5 => x(8),
      O => \x_color__29_carry__0_i_2_n_0\
    );
\x_color__29_carry__0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00009666"
    )
        port map (
      I0 => \x_color__0_carry__1_n_4\,
      I1 => \x_color__0_carry__1_n_6\,
      I2 => \x_color__0_carry__1_n_7\,
      I3 => \x_color__0_carry__1_n_5\,
      I4 => x(7),
      O => \x_color__29_carry__0_i_3_n_0\
    );
\x_color__29_carry__0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02ABD540FD542ABF"
    )
        port map (
      I0 => x(9),
      I1 => \x_color__0_carry__1_n_5\,
      I2 => \x_color__29_carry__0_i_7_n_0\,
      I3 => \x_color__0_carry__1_n_4\,
      I4 => \x_color__0_carry__2_n_7\,
      I5 => x(10),
      O => \x_color__29_carry__0_i_4_n_0\
    );
\x_color__29_carry__0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"422BBDD4BDD4422B"
    )
        port map (
      I0 => x(8),
      I1 => \x_color__29_carry__0_i_7_n_0\,
      I2 => \x_color__0_carry__2_n_7\,
      I3 => \x_color__0_carry__1_n_5\,
      I4 => \x_color__0_carry__1_n_4\,
      I5 => x(9),
      O => \x_color__29_carry__0_i_5_n_0\
    );
\x_color__29_carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69969669"
    )
        port map (
      I0 => \x_color__29_carry__0_i_3_n_0\,
      I1 => \x_color__29_carry__0_i_7_n_0\,
      I2 => \x_color__0_carry__1_n_5\,
      I3 => \x_color__0_carry__2_n_7\,
      I4 => x(8),
      O => \x_color__29_carry__0_i_6_n_0\
    );
\x_color__29_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E888"
    )
        port map (
      I0 => \x_color__0_carry__1_n_6\,
      I1 => \x_color__0_carry__1_n_4\,
      I2 => \x_color__0_carry__1_n_5\,
      I3 => \x_color__0_carry__1_n_7\,
      O => \x_color__29_carry__0_i_7_n_0\
    );
\x_color__29_carry_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6F"
    )
        port map (
      I0 => \x_color__0_carry__1_n_7\,
      I1 => \x_color__0_carry__1_n_5\,
      I2 => x(6),
      O => \x_color__29_carry_i_1_n_0\
    );
\x_color__29_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \x_color__0_carry__1_n_6\,
      I1 => x(5),
      O => \x_color__29_carry_i_2_n_0\
    );
\x_color__29_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \x_color__0_carry__1_n_7\,
      I1 => x(4),
      O => \x_color__29_carry_i_3_n_0\
    );
\x_color__29_carry_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BD4242BD42BDBD42"
    )
        port map (
      I0 => x(6),
      I1 => \x_color__0_carry__1_n_5\,
      I2 => \x_color__0_carry__1_n_7\,
      I3 => \x_color__0_carry__1_n_6\,
      I4 => \x_color__0_carry__1_n_4\,
      I5 => x(7),
      O => \x_color__29_carry_i_4_n_0\
    );
\x_color__29_carry_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \x_color__29_carry_i_2_n_0\,
      I1 => \x_color__0_carry__1_n_5\,
      I2 => \x_color__0_carry__1_n_7\,
      I3 => x(6),
      O => \x_color__29_carry_i_5_n_0\
    );
\x_color__29_carry_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6696"
    )
        port map (
      I0 => \x_color__0_carry__1_n_6\,
      I1 => x(5),
      I2 => x(4),
      I3 => \x_color__0_carry__1_n_7\,
      O => \x_color__29_carry_i_6_n_0\
    );
\x_color__29_carry_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => x(4),
      I1 => \x_color__0_carry__1_n_7\,
      O => \x_color__29_carry_i_7_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_colorbar_0_0 is
  port (
    x : in STD_LOGIC_VECTOR ( 10 downto 0 );
    y : in STD_LOGIC_VECTOR ( 9 downto 0 );
    active_video : in STD_LOGIC;
    rgb : out STD_LOGIC_VECTOR ( 23 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_colorbar_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_colorbar_0_0 : entity is "design_1_colorbar_0_0,colorbar,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_1_colorbar_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_1_colorbar_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of design_1_colorbar_0_0 : entity is "colorbar,Vivado 2025.2";
end design_1_colorbar_0_0;

architecture STRUCTURE of design_1_colorbar_0_0 is
  signal \^rgb\ : STD_LOGIC_VECTOR ( 23 downto 7 );
begin
  rgb(23) <= \^rgb\(23);
  rgb(22) <= \^rgb\(23);
  rgb(21) <= \^rgb\(23);
  rgb(20) <= \^rgb\(23);
  rgb(19) <= \^rgb\(23);
  rgb(18) <= \^rgb\(23);
  rgb(17) <= \^rgb\(23);
  rgb(16) <= \^rgb\(23);
  rgb(15) <= \^rgb\(15);
  rgb(14) <= \^rgb\(15);
  rgb(13) <= \^rgb\(15);
  rgb(12) <= \^rgb\(15);
  rgb(11) <= \^rgb\(15);
  rgb(10) <= \^rgb\(15);
  rgb(9) <= \^rgb\(15);
  rgb(8) <= \^rgb\(15);
  rgb(7) <= \^rgb\(7);
  rgb(6) <= \^rgb\(7);
  rgb(5) <= \^rgb\(7);
  rgb(4) <= \^rgb\(7);
  rgb(3) <= \^rgb\(7);
  rgb(2) <= \^rgb\(7);
  rgb(1) <= \^rgb\(7);
  rgb(0) <= \^rgb\(7);
inst: entity work.design_1_colorbar_0_0_colorbar
     port map (
      active_video => active_video,
      rgb(2) => \^rgb\(23),
      rgb(1) => \^rgb\(15),
      rgb(0) => \^rgb\(7),
      x(10 downto 0) => x(10 downto 0)
    );
end STRUCTURE;
