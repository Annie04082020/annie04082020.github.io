// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Aug  4 16:08:17 2026
// Host        : DVSY-62334655 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/DVSY_62334655/Documents/vivado/001_projects/HDMI/HDMI.gen/sources_1/bd/design_1/ip/design_1_colorbar_0_0/design_1_colorbar_0_0_stub.v
// Design      : design_1_colorbar_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "design_1_colorbar_0_0,colorbar,{}" *) (* CORE_GENERATION_INFO = "design_1_colorbar_0_0,colorbar,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=colorbar,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "colorbar,Vivado 2025.2" *) 
module design_1_colorbar_0_0(x, y, active_video, rgb)
/* synthesis syn_black_box black_box_pad_pin="x[10:0],y[9:0],active_video,rgb[23:0]" */;
  input [10:0]x;
  input [9:0]y;
  input active_video;
  output [23:0]rgb;
endmodule
