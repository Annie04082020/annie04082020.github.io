// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Aug  4 16:08:17 2026
// Host        : DVSY-62334655 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/DVSY_62334655/Documents/vivado/001_projects/HDMI/HDMI.gen/sources_1/bd/design_1/ip/design_1_video_timing_0_0/design_1_video_timing_0_0_sim_netlist.v
// Design      : design_1_video_timing_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_video_timing_0_0,video_timing,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "video_timing,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module design_1_video_timing_0_0
   (clk,
    rst,
    hsync,
    vsync,
    active_video,
    x,
    y);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_RESET rst, FREQ_HZ 25178571, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *) input clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 rst RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME rst, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input rst;
  output hsync;
  output vsync;
  output active_video;
  output [10:0]x;
  output [9:0]y;

  wire active_video;
  wire clk;
  wire hsync;
  wire vsync;
  wire [10:0]x;
  wire [9:0]y;

  design_1_video_timing_0_0_video_timing inst
       (.Q(x),
        .active_video(active_video),
        .clk(clk),
        .hsync(hsync),
        .\v_cnt_reg[0]_0 (y[0]),
        .\v_cnt_reg[1]_0 (y[1]),
        .\v_cnt_reg[2]_0 (y[2]),
        .\v_cnt_reg[3]_0 (y[3]),
        .\v_cnt_reg[4]_0 (y[4]),
        .\v_cnt_reg[5]_0 (y[5]),
        .\v_cnt_reg[6]_0 (y[6]),
        .\v_cnt_reg[7]_0 (y[7]),
        .\v_cnt_reg[8]_0 (y[8]),
        .\v_cnt_reg[9]_0 (y[9]),
        .vsync(vsync));
endmodule

(* ORIG_REF_NAME = "video_timing" *) 
module design_1_video_timing_0_0_video_timing
   (\v_cnt_reg[0]_0 ,
    Q,
    \v_cnt_reg[9]_0 ,
    \v_cnt_reg[8]_0 ,
    \v_cnt_reg[7]_0 ,
    \v_cnt_reg[6]_0 ,
    \v_cnt_reg[5]_0 ,
    \v_cnt_reg[4]_0 ,
    \v_cnt_reg[3]_0 ,
    \v_cnt_reg[2]_0 ,
    \v_cnt_reg[1]_0 ,
    vsync,
    active_video,
    hsync,
    clk);
  output \v_cnt_reg[0]_0 ;
  output [10:0]Q;
  output \v_cnt_reg[9]_0 ;
  output \v_cnt_reg[8]_0 ;
  output \v_cnt_reg[7]_0 ;
  output \v_cnt_reg[6]_0 ;
  output \v_cnt_reg[5]_0 ;
  output \v_cnt_reg[4]_0 ;
  output \v_cnt_reg[3]_0 ;
  output \v_cnt_reg[2]_0 ;
  output \v_cnt_reg[1]_0 ;
  output vsync;
  output active_video;
  output hsync;
  input clk;

  wire [10:0]Q;
  wire active_video;
  wire clk;
  wire [9:1]data0;
  wire \h_cnt[10]_i_3_n_0 ;
  wire \h_cnt[10]_i_4_n_0 ;
  wire hsync;
  wire hsync_INST_0_i_1_n_0;
  wire p_0_in;
  wire [10:0]p_1_in;
  wire \v_cnt[0]_i_1_n_0 ;
  wire \v_cnt[9]_i_1_n_0 ;
  wire \v_cnt[9]_i_3_n_0 ;
  wire \v_cnt[9]_i_4_n_0 ;
  wire \v_cnt[9]_i_5_n_0 ;
  wire \v_cnt[9]_i_6_n_0 ;
  wire \v_cnt_reg[0]_0 ;
  wire \v_cnt_reg[1]_0 ;
  wire \v_cnt_reg[2]_0 ;
  wire \v_cnt_reg[3]_0 ;
  wire \v_cnt_reg[4]_0 ;
  wire \v_cnt_reg[5]_0 ;
  wire \v_cnt_reg[6]_0 ;
  wire \v_cnt_reg[7]_0 ;
  wire \v_cnt_reg[8]_0 ;
  wire \v_cnt_reg[9]_0 ;
  wire vsync;
  wire vsync_INST_0_i_1_n_0;

  LUT6 #(
    .INIT(64'h0000001F00000000)) 
    active_video_INST_0
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[9]),
        .I3(Q[10]),
        .I4(\v_cnt_reg[9]_0 ),
        .I5(vsync_INST_0_i_1_n_0),
        .O(active_video));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \h_cnt[0]_i_1 
       (.I0(Q[0]),
        .O(p_1_in[0]));
  LUT6 #(
    .INIT(64'h0001000000000000)) 
    \h_cnt[10]_i_1 
       (.I0(hsync_INST_0_i_1_n_0),
        .I1(Q[6]),
        .I2(Q[5]),
        .I3(Q[7]),
        .I4(Q[8]),
        .I5(\h_cnt[10]_i_3_n_0 ),
        .O(p_0_in));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \h_cnt[10]_i_2 
       (.I0(\h_cnt[10]_i_4_n_0 ),
        .I1(\h_cnt[10]_i_3_n_0 ),
        .I2(Q[9]),
        .I3(Q[8]),
        .I4(Q[7]),
        .I5(Q[10]),
        .O(p_1_in[10]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \h_cnt[10]_i_3 
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(Q[4]),
        .O(\h_cnt[10]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \h_cnt[10]_i_4 
       (.I0(Q[5]),
        .I1(Q[6]),
        .O(\h_cnt[10]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \h_cnt[1]_i_1 
       (.I0(Q[0]),
        .I1(Q[1]),
        .O(p_1_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \h_cnt[2]_i_1 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(Q[2]),
        .O(p_1_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \h_cnt[3]_i_1 
       (.I0(Q[2]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .O(p_1_in[3]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \h_cnt[4]_i_1 
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(Q[4]),
        .O(p_1_in[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \h_cnt[5]_i_1 
       (.I0(Q[4]),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[3]),
        .I5(Q[5]),
        .O(p_1_in[5]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \h_cnt[6]_i_1 
       (.I0(Q[5]),
        .I1(\h_cnt[10]_i_3_n_0 ),
        .I2(Q[6]),
        .O(p_1_in[6]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \h_cnt[7]_i_1 
       (.I0(\h_cnt[10]_i_3_n_0 ),
        .I1(Q[5]),
        .I2(Q[6]),
        .I3(Q[7]),
        .O(p_1_in[7]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \h_cnt[8]_i_1 
       (.I0(Q[7]),
        .I1(Q[6]),
        .I2(Q[5]),
        .I3(\h_cnt[10]_i_3_n_0 ),
        .I4(Q[8]),
        .O(p_1_in[8]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \h_cnt[9]_i_1 
       (.I0(Q[6]),
        .I1(Q[5]),
        .I2(\h_cnt[10]_i_3_n_0 ),
        .I3(Q[7]),
        .I4(Q[8]),
        .I5(Q[9]),
        .O(p_1_in[9]));
  FDRE \h_cnt_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(p_1_in[0]),
        .Q(Q[0]),
        .R(p_0_in));
  FDRE \h_cnt_reg[10] 
       (.C(clk),
        .CE(1'b1),
        .D(p_1_in[10]),
        .Q(Q[10]),
        .R(p_0_in));
  FDRE \h_cnt_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(p_1_in[1]),
        .Q(Q[1]),
        .R(p_0_in));
  FDRE \h_cnt_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(p_1_in[2]),
        .Q(Q[2]),
        .R(p_0_in));
  FDRE \h_cnt_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(p_1_in[3]),
        .Q(Q[3]),
        .R(p_0_in));
  FDRE \h_cnt_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(p_1_in[4]),
        .Q(Q[4]),
        .R(p_0_in));
  FDRE \h_cnt_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .D(p_1_in[5]),
        .Q(Q[5]),
        .R(p_0_in));
  FDRE \h_cnt_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(p_1_in[6]),
        .Q(Q[6]),
        .R(p_0_in));
  FDRE \h_cnt_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(p_1_in[7]),
        .Q(Q[7]),
        .R(p_0_in));
  FDRE \h_cnt_reg[8] 
       (.C(clk),
        .CE(1'b1),
        .D(p_1_in[8]),
        .Q(Q[8]),
        .R(p_0_in));
  FDRE \h_cnt_reg[9] 
       (.C(clk),
        .CE(1'b1),
        .D(p_1_in[9]),
        .Q(Q[9]),
        .R(p_0_in));
  LUT6 #(
    .INIT(64'hFEEEEEEFFFFFFFFF)) 
    hsync_INST_0
       (.I0(Q[8]),
        .I1(hsync_INST_0_i_1_n_0),
        .I2(Q[4]),
        .I3(Q[5]),
        .I4(Q[6]),
        .I5(Q[7]),
        .O(hsync));
  LUT2 #(
    .INIT(4'hB)) 
    hsync_INST_0_i_1
       (.I0(Q[10]),
        .I1(Q[9]),
        .O(hsync_INST_0_i_1_n_0));
  LUT5 #(
    .INIT(32'h0FFFE000)) 
    \v_cnt[0]_i_1 
       (.I0(\v_cnt[9]_i_5_n_0 ),
        .I1(\v_cnt[9]_i_4_n_0 ),
        .I2(\v_cnt[9]_i_3_n_0 ),
        .I3(\h_cnt[10]_i_3_n_0 ),
        .I4(\v_cnt_reg[0]_0 ),
        .O(\v_cnt[0]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \v_cnt[1]_i_1 
       (.I0(\v_cnt_reg[0]_0 ),
        .I1(\v_cnt_reg[1]_0 ),
        .O(data0[1]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \v_cnt[2]_i_1 
       (.I0(\v_cnt_reg[1]_0 ),
        .I1(\v_cnt_reg[0]_0 ),
        .I2(\v_cnt_reg[2]_0 ),
        .O(data0[2]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \v_cnt[3]_i_1 
       (.I0(\v_cnt_reg[2]_0 ),
        .I1(\v_cnt_reg[0]_0 ),
        .I2(\v_cnt_reg[1]_0 ),
        .I3(\v_cnt_reg[3]_0 ),
        .O(data0[3]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \v_cnt[4]_i_1 
       (.I0(\v_cnt_reg[2]_0 ),
        .I1(\v_cnt_reg[3]_0 ),
        .I2(\v_cnt_reg[0]_0 ),
        .I3(\v_cnt_reg[1]_0 ),
        .I4(\v_cnt_reg[4]_0 ),
        .O(data0[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \v_cnt[5]_i_1 
       (.I0(\v_cnt_reg[4]_0 ),
        .I1(\v_cnt_reg[1]_0 ),
        .I2(\v_cnt_reg[0]_0 ),
        .I3(\v_cnt_reg[3]_0 ),
        .I4(\v_cnt_reg[2]_0 ),
        .I5(\v_cnt_reg[5]_0 ),
        .O(data0[5]));
  LUT3 #(
    .INIT(8'h78)) 
    \v_cnt[6]_i_1 
       (.I0(\v_cnt_reg[5]_0 ),
        .I1(\v_cnt[9]_i_6_n_0 ),
        .I2(\v_cnt_reg[6]_0 ),
        .O(data0[6]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \v_cnt[7]_i_1 
       (.I0(\v_cnt_reg[5]_0 ),
        .I1(\v_cnt_reg[6]_0 ),
        .I2(\v_cnt[9]_i_6_n_0 ),
        .I3(\v_cnt_reg[7]_0 ),
        .O(data0[7]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \v_cnt[8]_i_1 
       (.I0(\v_cnt_reg[6]_0 ),
        .I1(\v_cnt_reg[5]_0 ),
        .I2(\v_cnt_reg[7]_0 ),
        .I3(\v_cnt[9]_i_6_n_0 ),
        .I4(\v_cnt_reg[8]_0 ),
        .O(data0[8]));
  LUT5 #(
    .INIT(32'h00000008)) 
    \v_cnt[9]_i_1 
       (.I0(\h_cnt[10]_i_3_n_0 ),
        .I1(\v_cnt[9]_i_3_n_0 ),
        .I2(\v_cnt_reg[0]_0 ),
        .I3(\v_cnt[9]_i_4_n_0 ),
        .I4(\v_cnt[9]_i_5_n_0 ),
        .O(\v_cnt[9]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \v_cnt[9]_i_2 
       (.I0(\v_cnt_reg[7]_0 ),
        .I1(\v_cnt_reg[5]_0 ),
        .I2(\v_cnt_reg[6]_0 ),
        .I3(\v_cnt_reg[8]_0 ),
        .I4(\v_cnt[9]_i_6_n_0 ),
        .I5(\v_cnt_reg[9]_0 ),
        .O(data0[9]));
  LUT6 #(
    .INIT(64'h0000000000020000)) 
    \v_cnt[9]_i_3 
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(Q[6]),
        .I4(Q[9]),
        .I5(Q[10]),
        .O(\v_cnt[9]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFBF)) 
    \v_cnt[9]_i_4 
       (.I0(\v_cnt_reg[1]_0 ),
        .I1(\v_cnt_reg[2]_0 ),
        .I2(\v_cnt_reg[3]_0 ),
        .I3(\v_cnt_reg[5]_0 ),
        .I4(\v_cnt_reg[4]_0 ),
        .O(\v_cnt[9]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'hFFEF)) 
    \v_cnt[9]_i_5 
       (.I0(\v_cnt_reg[7]_0 ),
        .I1(\v_cnt_reg[6]_0 ),
        .I2(\v_cnt_reg[9]_0 ),
        .I3(\v_cnt_reg[8]_0 ),
        .O(\v_cnt[9]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \v_cnt[9]_i_6 
       (.I0(\v_cnt_reg[2]_0 ),
        .I1(\v_cnt_reg[3]_0 ),
        .I2(\v_cnt_reg[0]_0 ),
        .I3(\v_cnt_reg[1]_0 ),
        .I4(\v_cnt_reg[4]_0 ),
        .O(\v_cnt[9]_i_6_n_0 ));
  FDRE \v_cnt_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\v_cnt[0]_i_1_n_0 ),
        .Q(\v_cnt_reg[0]_0 ),
        .R(1'b0));
  FDRE \v_cnt_reg[1] 
       (.C(clk),
        .CE(p_0_in),
        .D(data0[1]),
        .Q(\v_cnt_reg[1]_0 ),
        .R(\v_cnt[9]_i_1_n_0 ));
  FDRE \v_cnt_reg[2] 
       (.C(clk),
        .CE(p_0_in),
        .D(data0[2]),
        .Q(\v_cnt_reg[2]_0 ),
        .R(\v_cnt[9]_i_1_n_0 ));
  FDRE \v_cnt_reg[3] 
       (.C(clk),
        .CE(p_0_in),
        .D(data0[3]),
        .Q(\v_cnt_reg[3]_0 ),
        .R(\v_cnt[9]_i_1_n_0 ));
  FDRE \v_cnt_reg[4] 
       (.C(clk),
        .CE(p_0_in),
        .D(data0[4]),
        .Q(\v_cnt_reg[4]_0 ),
        .R(\v_cnt[9]_i_1_n_0 ));
  FDRE \v_cnt_reg[5] 
       (.C(clk),
        .CE(p_0_in),
        .D(data0[5]),
        .Q(\v_cnt_reg[5]_0 ),
        .R(\v_cnt[9]_i_1_n_0 ));
  FDRE \v_cnt_reg[6] 
       (.C(clk),
        .CE(p_0_in),
        .D(data0[6]),
        .Q(\v_cnt_reg[6]_0 ),
        .R(\v_cnt[9]_i_1_n_0 ));
  FDRE \v_cnt_reg[7] 
       (.C(clk),
        .CE(p_0_in),
        .D(data0[7]),
        .Q(\v_cnt_reg[7]_0 ),
        .R(\v_cnt[9]_i_1_n_0 ));
  FDRE \v_cnt_reg[8] 
       (.C(clk),
        .CE(p_0_in),
        .D(data0[8]),
        .Q(\v_cnt_reg[8]_0 ),
        .R(\v_cnt[9]_i_1_n_0 ));
  FDRE \v_cnt_reg[9] 
       (.C(clk),
        .CE(p_0_in),
        .D(data0[9]),
        .Q(\v_cnt_reg[9]_0 ),
        .R(\v_cnt[9]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFEFFFFFF)) 
    vsync_INST_0
       (.I0(\v_cnt_reg[4]_0 ),
        .I1(\v_cnt_reg[9]_0 ),
        .I2(\v_cnt_reg[2]_0 ),
        .I3(\v_cnt_reg[1]_0 ),
        .I4(\v_cnt_reg[3]_0 ),
        .I5(vsync_INST_0_i_1_n_0),
        .O(vsync));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    vsync_INST_0_i_1
       (.I0(\v_cnt_reg[7]_0 ),
        .I1(\v_cnt_reg[5]_0 ),
        .I2(\v_cnt_reg[6]_0 ),
        .I3(\v_cnt_reg[8]_0 ),
        .O(vsync_INST_0_i_1_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
