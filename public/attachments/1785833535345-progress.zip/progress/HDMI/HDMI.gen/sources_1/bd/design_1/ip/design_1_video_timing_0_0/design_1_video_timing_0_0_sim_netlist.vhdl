-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Aug  4 16:08:17 2026
-- Host        : DVSY-62334655 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/DVSY_62334655/Documents/vivado/001_projects/HDMI/HDMI.gen/sources_1/bd/design_1/ip/design_1_video_timing_0_0/design_1_video_timing_0_0_sim_netlist.vhdl
-- Design      : design_1_video_timing_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z010clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_video_timing_0_0_video_timing is
  port (
    \v_cnt_reg[0]_0\ : out STD_LOGIC;
    Q : out STD_LOGIC_VECTOR ( 10 downto 0 );
    \v_cnt_reg[9]_0\ : out STD_LOGIC;
    \v_cnt_reg[8]_0\ : out STD_LOGIC;
    \v_cnt_reg[7]_0\ : out STD_LOGIC;
    \v_cnt_reg[6]_0\ : out STD_LOGIC;
    \v_cnt_reg[5]_0\ : out STD_LOGIC;
    \v_cnt_reg[4]_0\ : out STD_LOGIC;
    \v_cnt_reg[3]_0\ : out STD_LOGIC;
    \v_cnt_reg[2]_0\ : out STD_LOGIC;
    \v_cnt_reg[1]_0\ : out STD_LOGIC;
    vsync : out STD_LOGIC;
    active_video : out STD_LOGIC;
    hsync : out STD_LOGIC;
    clk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_video_timing_0_0_video_timing : entity is "video_timing";
end design_1_video_timing_0_0_video_timing;

architecture STRUCTURE of design_1_video_timing_0_0_video_timing is
  signal \^q\ : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal data0 : STD_LOGIC_VECTOR ( 9 downto 1 );
  signal \h_cnt[10]_i_3_n_0\ : STD_LOGIC;
  signal \h_cnt[10]_i_4_n_0\ : STD_LOGIC;
  signal hsync_INST_0_i_1_n_0 : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  signal p_1_in : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal \v_cnt[0]_i_1_n_0\ : STD_LOGIC;
  signal \v_cnt[9]_i_1_n_0\ : STD_LOGIC;
  signal \v_cnt[9]_i_3_n_0\ : STD_LOGIC;
  signal \v_cnt[9]_i_4_n_0\ : STD_LOGIC;
  signal \v_cnt[9]_i_5_n_0\ : STD_LOGIC;
  signal \v_cnt[9]_i_6_n_0\ : STD_LOGIC;
  signal \^v_cnt_reg[0]_0\ : STD_LOGIC;
  signal \^v_cnt_reg[1]_0\ : STD_LOGIC;
  signal \^v_cnt_reg[2]_0\ : STD_LOGIC;
  signal \^v_cnt_reg[3]_0\ : STD_LOGIC;
  signal \^v_cnt_reg[4]_0\ : STD_LOGIC;
  signal \^v_cnt_reg[5]_0\ : STD_LOGIC;
  signal \^v_cnt_reg[6]_0\ : STD_LOGIC;
  signal \^v_cnt_reg[7]_0\ : STD_LOGIC;
  signal \^v_cnt_reg[8]_0\ : STD_LOGIC;
  signal \^v_cnt_reg[9]_0\ : STD_LOGIC;
  signal vsync_INST_0_i_1_n_0 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \h_cnt[0]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \h_cnt[10]_i_3\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \h_cnt[10]_i_4\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \h_cnt[1]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \h_cnt[2]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \h_cnt[3]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \h_cnt[4]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \h_cnt[6]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \h_cnt[7]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \h_cnt[8]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \v_cnt[2]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \v_cnt[3]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \v_cnt[4]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \v_cnt[7]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \v_cnt[8]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \v_cnt[9]_i_5\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \v_cnt[9]_i_6\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of vsync_INST_0_i_1 : label is "soft_lutpair4";
begin
  Q(10 downto 0) <= \^q\(10 downto 0);
  \v_cnt_reg[0]_0\ <= \^v_cnt_reg[0]_0\;
  \v_cnt_reg[1]_0\ <= \^v_cnt_reg[1]_0\;
  \v_cnt_reg[2]_0\ <= \^v_cnt_reg[2]_0\;
  \v_cnt_reg[3]_0\ <= \^v_cnt_reg[3]_0\;
  \v_cnt_reg[4]_0\ <= \^v_cnt_reg[4]_0\;
  \v_cnt_reg[5]_0\ <= \^v_cnt_reg[5]_0\;
  \v_cnt_reg[6]_0\ <= \^v_cnt_reg[6]_0\;
  \v_cnt_reg[7]_0\ <= \^v_cnt_reg[7]_0\;
  \v_cnt_reg[8]_0\ <= \^v_cnt_reg[8]_0\;
  \v_cnt_reg[9]_0\ <= \^v_cnt_reg[9]_0\;
active_video_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000001F00000000"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(7),
      I2 => \^q\(9),
      I3 => \^q\(10),
      I4 => \^v_cnt_reg[9]_0\,
      I5 => vsync_INST_0_i_1_n_0,
      O => active_video
    );
\h_cnt[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^q\(0),
      O => p_1_in(0)
    );
\h_cnt[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0001000000000000"
    )
        port map (
      I0 => hsync_INST_0_i_1_n_0,
      I1 => \^q\(6),
      I2 => \^q\(5),
      I3 => \^q\(7),
      I4 => \^q\(8),
      I5 => \h_cnt[10]_i_3_n_0\,
      O => p_0_in
    );
\h_cnt[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => \h_cnt[10]_i_4_n_0\,
      I1 => \h_cnt[10]_i_3_n_0\,
      I2 => \^q\(9),
      I3 => \^q\(8),
      I4 => \^q\(7),
      I5 => \^q\(10),
      O => p_1_in(10)
    );
\h_cnt[10]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(1),
      I2 => \^q\(0),
      I3 => \^q\(2),
      I4 => \^q\(4),
      O => \h_cnt[10]_i_3_n_0\
    );
\h_cnt[10]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^q\(5),
      I1 => \^q\(6),
      O => \h_cnt[10]_i_4_n_0\
    );
\h_cnt[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^q\(1),
      O => p_1_in(1)
    );
\h_cnt[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \^q\(1),
      I1 => \^q\(0),
      I2 => \^q\(2),
      O => p_1_in(2)
    );
\h_cnt[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \^q\(2),
      I1 => \^q\(0),
      I2 => \^q\(1),
      I3 => \^q\(3),
      O => p_1_in(3)
    );
\h_cnt[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(1),
      I2 => \^q\(0),
      I3 => \^q\(2),
      I4 => \^q\(4),
      O => p_1_in(4)
    );
\h_cnt[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => \^q\(4),
      I1 => \^q\(2),
      I2 => \^q\(0),
      I3 => \^q\(1),
      I4 => \^q\(3),
      I5 => \^q\(5),
      O => p_1_in(5)
    );
\h_cnt[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \^q\(5),
      I1 => \h_cnt[10]_i_3_n_0\,
      I2 => \^q\(6),
      O => p_1_in(6)
    );
\h_cnt[7]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \h_cnt[10]_i_3_n_0\,
      I1 => \^q\(5),
      I2 => \^q\(6),
      I3 => \^q\(7),
      O => p_1_in(7)
    );
\h_cnt[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \^q\(7),
      I1 => \^q\(6),
      I2 => \^q\(5),
      I3 => \h_cnt[10]_i_3_n_0\,
      I4 => \^q\(8),
      O => p_1_in(8)
    );
\h_cnt[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => \^q\(6),
      I1 => \^q\(5),
      I2 => \h_cnt[10]_i_3_n_0\,
      I3 => \^q\(7),
      I4 => \^q\(8),
      I5 => \^q\(9),
      O => p_1_in(9)
    );
\h_cnt_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => p_1_in(0),
      Q => \^q\(0),
      R => p_0_in
    );
\h_cnt_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => p_1_in(10),
      Q => \^q\(10),
      R => p_0_in
    );
\h_cnt_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => p_1_in(1),
      Q => \^q\(1),
      R => p_0_in
    );
\h_cnt_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => p_1_in(2),
      Q => \^q\(2),
      R => p_0_in
    );
\h_cnt_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => p_1_in(3),
      Q => \^q\(3),
      R => p_0_in
    );
\h_cnt_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => p_1_in(4),
      Q => \^q\(4),
      R => p_0_in
    );
\h_cnt_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => p_1_in(5),
      Q => \^q\(5),
      R => p_0_in
    );
\h_cnt_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => p_1_in(6),
      Q => \^q\(6),
      R => p_0_in
    );
\h_cnt_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => p_1_in(7),
      Q => \^q\(7),
      R => p_0_in
    );
\h_cnt_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => p_1_in(8),
      Q => \^q\(8),
      R => p_0_in
    );
\h_cnt_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => p_1_in(9),
      Q => \^q\(9),
      R => p_0_in
    );
hsync_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEEEEEEFFFFFFFFF"
    )
        port map (
      I0 => \^q\(8),
      I1 => hsync_INST_0_i_1_n_0,
      I2 => \^q\(4),
      I3 => \^q\(5),
      I4 => \^q\(6),
      I5 => \^q\(7),
      O => hsync
    );
hsync_INST_0_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^q\(10),
      I1 => \^q\(9),
      O => hsync_INST_0_i_1_n_0
    );
\v_cnt[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0FFFE000"
    )
        port map (
      I0 => \v_cnt[9]_i_5_n_0\,
      I1 => \v_cnt[9]_i_4_n_0\,
      I2 => \v_cnt[9]_i_3_n_0\,
      I3 => \h_cnt[10]_i_3_n_0\,
      I4 => \^v_cnt_reg[0]_0\,
      O => \v_cnt[0]_i_1_n_0\
    );
\v_cnt[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^v_cnt_reg[0]_0\,
      I1 => \^v_cnt_reg[1]_0\,
      O => data0(1)
    );
\v_cnt[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \^v_cnt_reg[1]_0\,
      I1 => \^v_cnt_reg[0]_0\,
      I2 => \^v_cnt_reg[2]_0\,
      O => data0(2)
    );
\v_cnt[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \^v_cnt_reg[2]_0\,
      I1 => \^v_cnt_reg[0]_0\,
      I2 => \^v_cnt_reg[1]_0\,
      I3 => \^v_cnt_reg[3]_0\,
      O => data0(3)
    );
\v_cnt[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \^v_cnt_reg[2]_0\,
      I1 => \^v_cnt_reg[3]_0\,
      I2 => \^v_cnt_reg[0]_0\,
      I3 => \^v_cnt_reg[1]_0\,
      I4 => \^v_cnt_reg[4]_0\,
      O => data0(4)
    );
\v_cnt[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => \^v_cnt_reg[4]_0\,
      I1 => \^v_cnt_reg[1]_0\,
      I2 => \^v_cnt_reg[0]_0\,
      I3 => \^v_cnt_reg[3]_0\,
      I4 => \^v_cnt_reg[2]_0\,
      I5 => \^v_cnt_reg[5]_0\,
      O => data0(5)
    );
\v_cnt[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \^v_cnt_reg[5]_0\,
      I1 => \v_cnt[9]_i_6_n_0\,
      I2 => \^v_cnt_reg[6]_0\,
      O => data0(6)
    );
\v_cnt[7]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \^v_cnt_reg[5]_0\,
      I1 => \^v_cnt_reg[6]_0\,
      I2 => \v_cnt[9]_i_6_n_0\,
      I3 => \^v_cnt_reg[7]_0\,
      O => data0(7)
    );
\v_cnt[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \^v_cnt_reg[6]_0\,
      I1 => \^v_cnt_reg[5]_0\,
      I2 => \^v_cnt_reg[7]_0\,
      I3 => \v_cnt[9]_i_6_n_0\,
      I4 => \^v_cnt_reg[8]_0\,
      O => data0(8)
    );
\v_cnt[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000008"
    )
        port map (
      I0 => \h_cnt[10]_i_3_n_0\,
      I1 => \v_cnt[9]_i_3_n_0\,
      I2 => \^v_cnt_reg[0]_0\,
      I3 => \v_cnt[9]_i_4_n_0\,
      I4 => \v_cnt[9]_i_5_n_0\,
      O => \v_cnt[9]_i_1_n_0\
    );
\v_cnt[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => \^v_cnt_reg[7]_0\,
      I1 => \^v_cnt_reg[5]_0\,
      I2 => \^v_cnt_reg[6]_0\,
      I3 => \^v_cnt_reg[8]_0\,
      I4 => \v_cnt[9]_i_6_n_0\,
      I5 => \^v_cnt_reg[9]_0\,
      O => data0(9)
    );
\v_cnt[9]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000020000"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(7),
      I2 => \^q\(5),
      I3 => \^q\(6),
      I4 => \^q\(9),
      I5 => \^q\(10),
      O => \v_cnt[9]_i_3_n_0\
    );
\v_cnt[9]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFBF"
    )
        port map (
      I0 => \^v_cnt_reg[1]_0\,
      I1 => \^v_cnt_reg[2]_0\,
      I2 => \^v_cnt_reg[3]_0\,
      I3 => \^v_cnt_reg[5]_0\,
      I4 => \^v_cnt_reg[4]_0\,
      O => \v_cnt[9]_i_4_n_0\
    );
\v_cnt[9]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => \^v_cnt_reg[7]_0\,
      I1 => \^v_cnt_reg[6]_0\,
      I2 => \^v_cnt_reg[9]_0\,
      I3 => \^v_cnt_reg[8]_0\,
      O => \v_cnt[9]_i_5_n_0\
    );
\v_cnt[9]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \^v_cnt_reg[2]_0\,
      I1 => \^v_cnt_reg[3]_0\,
      I2 => \^v_cnt_reg[0]_0\,
      I3 => \^v_cnt_reg[1]_0\,
      I4 => \^v_cnt_reg[4]_0\,
      O => \v_cnt[9]_i_6_n_0\
    );
\v_cnt_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \v_cnt[0]_i_1_n_0\,
      Q => \^v_cnt_reg[0]_0\,
      R => '0'
    );
\v_cnt_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => p_0_in,
      D => data0(1),
      Q => \^v_cnt_reg[1]_0\,
      R => \v_cnt[9]_i_1_n_0\
    );
\v_cnt_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => p_0_in,
      D => data0(2),
      Q => \^v_cnt_reg[2]_0\,
      R => \v_cnt[9]_i_1_n_0\
    );
\v_cnt_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => p_0_in,
      D => data0(3),
      Q => \^v_cnt_reg[3]_0\,
      R => \v_cnt[9]_i_1_n_0\
    );
\v_cnt_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => p_0_in,
      D => data0(4),
      Q => \^v_cnt_reg[4]_0\,
      R => \v_cnt[9]_i_1_n_0\
    );
\v_cnt_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => p_0_in,
      D => data0(5),
      Q => \^v_cnt_reg[5]_0\,
      R => \v_cnt[9]_i_1_n_0\
    );
\v_cnt_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => p_0_in,
      D => data0(6),
      Q => \^v_cnt_reg[6]_0\,
      R => \v_cnt[9]_i_1_n_0\
    );
\v_cnt_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => p_0_in,
      D => data0(7),
      Q => \^v_cnt_reg[7]_0\,
      R => \v_cnt[9]_i_1_n_0\
    );
\v_cnt_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => p_0_in,
      D => data0(8),
      Q => \^v_cnt_reg[8]_0\,
      R => \v_cnt[9]_i_1_n_0\
    );
\v_cnt_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => p_0_in,
      D => data0(9),
      Q => \^v_cnt_reg[9]_0\,
      R => \v_cnt[9]_i_1_n_0\
    );
vsync_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFEFFFFFF"
    )
        port map (
      I0 => \^v_cnt_reg[4]_0\,
      I1 => \^v_cnt_reg[9]_0\,
      I2 => \^v_cnt_reg[2]_0\,
      I3 => \^v_cnt_reg[1]_0\,
      I4 => \^v_cnt_reg[3]_0\,
      I5 => vsync_INST_0_i_1_n_0,
      O => vsync
    );
vsync_INST_0_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => \^v_cnt_reg[7]_0\,
      I1 => \^v_cnt_reg[5]_0\,
      I2 => \^v_cnt_reg[6]_0\,
      I3 => \^v_cnt_reg[8]_0\,
      O => vsync_INST_0_i_1_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_video_timing_0_0 is
  port (
    clk : in STD_LOGIC;
    rst : in STD_LOGIC;
    hsync : out STD_LOGIC;
    vsync : out STD_LOGIC;
    active_video : out STD_LOGIC;
    x : out STD_LOGIC_VECTOR ( 10 downto 0 );
    y : out STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_video_timing_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_video_timing_0_0 : entity is "design_1_video_timing_0_0,video_timing,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_1_video_timing_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_1_video_timing_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of design_1_video_timing_0_0 : entity is "video_timing,Vivado 2025.2";
end design_1_video_timing_0_0;

architecture STRUCTURE of design_1_video_timing_0_0 is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of clk : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clk : signal is "XIL_INTERFACENAME clk, ASSOCIATED_RESET rst, FREQ_HZ 25178571, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of rst : signal is "xilinx.com:signal:reset:1.0 rst RST";
  attribute X_INTERFACE_MODE of rst : signal is "slave";
  attribute X_INTERFACE_PARAMETER of rst : signal is "XIL_INTERFACENAME rst, POLARITY ACTIVE_LOW, INSERT_VIP 0";
begin
inst: entity work.design_1_video_timing_0_0_video_timing
     port map (
      Q(10 downto 0) => x(10 downto 0),
      active_video => active_video,
      clk => clk,
      hsync => hsync,
      \v_cnt_reg[0]_0\ => y(0),
      \v_cnt_reg[1]_0\ => y(1),
      \v_cnt_reg[2]_0\ => y(2),
      \v_cnt_reg[3]_0\ => y(3),
      \v_cnt_reg[4]_0\ => y(4),
      \v_cnt_reg[5]_0\ => y(5),
      \v_cnt_reg[6]_0\ => y(6),
      \v_cnt_reg[7]_0\ => y(7),
      \v_cnt_reg[8]_0\ => y(8),
      \v_cnt_reg[9]_0\ => y(9),
      vsync => vsync
    );
end STRUCTURE;
