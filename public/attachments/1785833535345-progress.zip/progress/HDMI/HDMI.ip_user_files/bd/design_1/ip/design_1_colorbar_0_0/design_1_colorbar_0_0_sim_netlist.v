// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Aug  4 14:26:35 2026
// Host        : DVSY-62334655 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/DVSY_62334655/Documents/vivado/001_projects/HDMI_colorbar/HDMI_colorbar.gen/sources_1/bd/design_1/ip/design_1_colorbar_0_0/design_1_colorbar_0_0_sim_netlist.v
// Design      : design_1_colorbar_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_colorbar_0_0,colorbar,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "colorbar,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module design_1_colorbar_0_0
   (active_video,
    pos_x,
    pos_y,
    rgb);
  input active_video;
  input [9:0]pos_x;
  input [8:0]pos_y;
  output [23:0]rgb;

  wire active_video;
  wire [9:0]pos_x;
  wire [23:7]\^rgb ;
  wire \rgb[0]_INST_0_i_1_n_0 ;
  wire \rgb[0]_INST_0_i_2_n_0 ;

  assign rgb[23] = \^rgb [23];
  assign rgb[22] = \^rgb [23];
  assign rgb[21] = \^rgb [23];
  assign rgb[20] = \^rgb [23];
  assign rgb[19] = \^rgb [23];
  assign rgb[18] = \^rgb [23];
  assign rgb[17] = \^rgb [23];
  assign rgb[16] = \^rgb [23];
  assign rgb[15] = \^rgb [15];
  assign rgb[14] = \^rgb [15];
  assign rgb[13] = \^rgb [15];
  assign rgb[12] = \^rgb [15];
  assign rgb[11] = \^rgb [15];
  assign rgb[10] = \^rgb [15];
  assign rgb[9] = \^rgb [15];
  assign rgb[8] = \^rgb [15];
  assign rgb[7] = \^rgb [7];
  assign rgb[6] = \^rgb [7];
  assign rgb[5] = \^rgb [7];
  assign rgb[4] = \^rgb [7];
  assign rgb[3] = \^rgb [7];
  assign rgb[2] = \^rgb [7];
  assign rgb[1] = \^rgb [7];
  assign rgb[0] = \^rgb [7];
  MUXF7 \rgb[0]_INST_0 
       (.I0(\rgb[0]_INST_0_i_1_n_0 ),
        .I1(\rgb[0]_INST_0_i_2_n_0 ),
        .O(\^rgb [7]),
        .S(pos_x[9]));
  LUT6 #(
    .INIT(64'hD0D22DBD00000000)) 
    \rgb[0]_INST_0_i_1 
       (.I0(pos_x[7]),
        .I1(pos_x[5]),
        .I2(pos_x[6]),
        .I3(pos_x[4]),
        .I4(pos_x[8]),
        .I5(active_video),
        .O(\rgb[0]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000011100000000)) 
    \rgb[0]_INST_0_i_2 
       (.I0(pos_x[8]),
        .I1(pos_x[7]),
        .I2(pos_x[4]),
        .I3(pos_x[5]),
        .I4(pos_x[6]),
        .I5(active_video),
        .O(\rgb[0]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000088AA2A2)) 
    \rgb[16]_INST_0 
       (.I0(active_video),
        .I1(pos_x[8]),
        .I2(pos_x[6]),
        .I3(pos_x[5]),
        .I4(pos_x[7]),
        .I5(pos_x[9]),
        .O(\^rgb [23]));
  LUT5 #(
    .INIT(32'h000002AA)) 
    \rgb[8]_INST_0 
       (.I0(active_video),
        .I1(pos_x[6]),
        .I2(pos_x[7]),
        .I3(pos_x[8]),
        .I4(pos_x[9]),
        .O(\^rgb [15]));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
