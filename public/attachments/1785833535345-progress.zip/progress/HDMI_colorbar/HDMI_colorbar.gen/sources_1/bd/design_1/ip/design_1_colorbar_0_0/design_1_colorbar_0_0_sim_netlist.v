// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Aug  4 16:07:14 2026
// Host        : DVSY-62334655 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/DVSY_62334655/Documents/vivado/001_projects/HDMI_colorbar/HDMI_colorbar.gen/sources_1/bd/design_1/ip/design_1_colorbar_0_0/design_1_colorbar_0_0_sim_netlist.v
// Design      : design_1_colorbar_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_colorbar_0_0,colorbar,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "colorbar,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module design_1_colorbar_0_0
   (x,
    y,
    active_video,
    rgb);
  input [10:0]x;
  input [9:0]y;
  input active_video;
  output [23:0]rgb;

  wire active_video;
  wire [23:7]\^rgb ;
  wire [10:0]x;

  assign rgb[23] = \^rgb [23];
  assign rgb[22] = \^rgb [23];
  assign rgb[21] = \^rgb [23];
  assign rgb[20] = \^rgb [23];
  assign rgb[19] = \^rgb [23];
  assign rgb[18] = \^rgb [23];
  assign rgb[17] = \^rgb [23];
  assign rgb[16] = \^rgb [23];
  assign rgb[15] = \^rgb [15];
  assign rgb[14] = \^rgb [15];
  assign rgb[13] = \^rgb [15];
  assign rgb[12] = \^rgb [15];
  assign rgb[11] = \^rgb [15];
  assign rgb[10] = \^rgb [15];
  assign rgb[9] = \^rgb [15];
  assign rgb[8] = \^rgb [15];
  assign rgb[7] = \^rgb [7];
  assign rgb[6] = \^rgb [7];
  assign rgb[5] = \^rgb [7];
  assign rgb[4] = \^rgb [7];
  assign rgb[3] = \^rgb [7];
  assign rgb[2] = \^rgb [7];
  assign rgb[1] = \^rgb [7];
  assign rgb[0] = \^rgb [7];
  design_1_colorbar_0_0_colorbar inst
       (.active_video(active_video),
        .rgb({\^rgb [23],\^rgb [15],\^rgb [7]}),
        .x(x));
endmodule

(* ORIG_REF_NAME = "colorbar" *) 
module design_1_colorbar_0_0_colorbar
   (rgb,
    x,
    active_video);
  output [2:0]rgb;
  input [10:0]x;
  input active_video;

  wire active_video;
  wire [2:0]rgb;
  wire \rgb[16]_INST_0_i_1_n_0 ;
  wire \rgb[8]_INST_0_i_1_n_0 ;
  wire [10:0]x;
  wire x_color__0_carry__0_i_1_n_0;
  wire x_color__0_carry__0_i_2_n_0;
  wire x_color__0_carry__0_i_3_n_0;
  wire x_color__0_carry__0_i_4_n_0;
  wire x_color__0_carry__0_i_5_n_0;
  wire x_color__0_carry__0_i_6_n_0;
  wire x_color__0_carry__0_i_7_n_0;
  wire x_color__0_carry__0_i_8_n_0;
  wire x_color__0_carry__0_n_0;
  wire x_color__0_carry__0_n_1;
  wire x_color__0_carry__0_n_2;
  wire x_color__0_carry__0_n_3;
  wire x_color__0_carry__1_i_1_n_0;
  wire x_color__0_carry__1_i_2_n_0;
  wire x_color__0_carry__1_i_3_n_0;
  wire x_color__0_carry__1_i_4_n_0;
  wire x_color__0_carry__1_i_5_n_0;
  wire x_color__0_carry__1_i_6_n_0;
  wire x_color__0_carry__1_i_7_n_0;
  wire x_color__0_carry__1_i_8_n_0;
  wire x_color__0_carry__1_n_0;
  wire x_color__0_carry__1_n_1;
  wire x_color__0_carry__1_n_2;
  wire x_color__0_carry__1_n_3;
  wire x_color__0_carry__1_n_4;
  wire x_color__0_carry__1_n_5;
  wire x_color__0_carry__1_n_6;
  wire x_color__0_carry__1_n_7;
  wire x_color__0_carry__2_i_1_n_0;
  wire x_color__0_carry__2_n_7;
  wire x_color__0_carry_i_1_n_0;
  wire x_color__0_carry_i_2_n_0;
  wire x_color__0_carry_i_3_n_0;
  wire x_color__0_carry_i_4_n_0;
  wire x_color__0_carry_i_5_n_0;
  wire x_color__0_carry_i_6_n_0;
  wire x_color__0_carry_i_7_n_0;
  wire x_color__0_carry_n_0;
  wire x_color__0_carry_n_1;
  wire x_color__0_carry_n_2;
  wire x_color__0_carry_n_3;
  wire x_color__29_carry__0_i_1_n_0;
  wire x_color__29_carry__0_i_2_n_0;
  wire x_color__29_carry__0_i_3_n_0;
  wire x_color__29_carry__0_i_4_n_0;
  wire x_color__29_carry__0_i_5_n_0;
  wire x_color__29_carry__0_i_6_n_0;
  wire x_color__29_carry__0_i_7_n_0;
  wire x_color__29_carry__0_n_1;
  wire x_color__29_carry__0_n_2;
  wire x_color__29_carry__0_n_3;
  wire x_color__29_carry_i_1_n_0;
  wire x_color__29_carry_i_2_n_0;
  wire x_color__29_carry_i_3_n_0;
  wire x_color__29_carry_i_4_n_0;
  wire x_color__29_carry_i_5_n_0;
  wire x_color__29_carry_i_6_n_0;
  wire x_color__29_carry_i_7_n_0;
  wire x_color__29_carry_n_0;
  wire x_color__29_carry_n_1;
  wire x_color__29_carry_n_2;
  wire x_color__29_carry_n_3;
  wire [3:0]NLW_x_color__0_carry_O_UNCONNECTED;
  wire [3:0]NLW_x_color__0_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_x_color__0_carry__2_CO_UNCONNECTED;
  wire [3:1]NLW_x_color__0_carry__2_O_UNCONNECTED;
  wire [3:0]NLW_x_color__29_carry_O_UNCONNECTED;
  wire [3:3]NLW_x_color__29_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_x_color__29_carry__0_O_UNCONNECTED;

  LUT5 #(
    .INIT(32'h6566FFFF)) 
    \rgb[0]_INST_0 
       (.I0(x_color__0_carry__1_n_7),
        .I1(x_color__29_carry__0_n_1),
        .I2(x[10]),
        .I3(\rgb[16]_INST_0_i_1_n_0 ),
        .I4(active_video),
        .O(rgb[0]));
  LUT6 #(
    .INIT(64'h55559959FFFFFFFF)) 
    \rgb[16]_INST_0 
       (.I0(x_color__0_carry__1_n_6),
        .I1(x_color__0_carry__1_n_7),
        .I2(\rgb[16]_INST_0_i_1_n_0 ),
        .I3(x[10]),
        .I4(x_color__29_carry__0_n_1),
        .I5(active_video),
        .O(rgb[2]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h0F5FA080)) 
    \rgb[16]_INST_0_i_1 
       (.I0(x_color__0_carry__1_n_5),
        .I1(x_color__0_carry__1_n_7),
        .I2(x_color__0_carry__1_n_4),
        .I3(x_color__0_carry__1_n_6),
        .I4(x_color__0_carry__2_n_7),
        .O(\rgb[16]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h55555595FFFFFFFF)) 
    \rgb[8]_INST_0 
       (.I0(x_color__0_carry__1_n_5),
        .I1(x_color__0_carry__1_n_6),
        .I2(x_color__0_carry__1_n_7),
        .I3(\rgb[8]_INST_0_i_1_n_0 ),
        .I4(x_color__29_carry__0_n_1),
        .I5(active_video),
        .O(rgb[1]));
  LUT6 #(
    .INIT(64'h000000005A4A2A2A)) 
    \rgb[8]_INST_0_i_1 
       (.I0(x_color__0_carry__2_n_7),
        .I1(x_color__0_carry__1_n_6),
        .I2(x_color__0_carry__1_n_4),
        .I3(x_color__0_carry__1_n_7),
        .I4(x_color__0_carry__1_n_5),
        .I5(x[10]),
        .O(\rgb[8]_INST_0_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 x_color__0_carry
       (.CI(1'b0),
        .CO({x_color__0_carry_n_0,x_color__0_carry_n_1,x_color__0_carry_n_2,x_color__0_carry_n_3}),
        .CYINIT(1'b0),
        .DI({x_color__0_carry_i_1_n_0,x_color__0_carry_i_2_n_0,x_color__0_carry_i_3_n_0,1'b0}),
        .O(NLW_x_color__0_carry_O_UNCONNECTED[3:0]),
        .S({x_color__0_carry_i_4_n_0,x_color__0_carry_i_5_n_0,x_color__0_carry_i_6_n_0,x_color__0_carry_i_7_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 x_color__0_carry__0
       (.CI(x_color__0_carry_n_0),
        .CO({x_color__0_carry__0_n_0,x_color__0_carry__0_n_1,x_color__0_carry__0_n_2,x_color__0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({x_color__0_carry__0_i_1_n_0,x_color__0_carry__0_i_2_n_0,x_color__0_carry__0_i_3_n_0,x_color__0_carry__0_i_4_n_0}),
        .O(NLW_x_color__0_carry__0_O_UNCONNECTED[3:0]),
        .S({x_color__0_carry__0_i_5_n_0,x_color__0_carry__0_i_6_n_0,x_color__0_carry__0_i_7_n_0,x_color__0_carry__0_i_8_n_0}));
  LUT3 #(
    .INIT(8'hD4)) 
    x_color__0_carry__0_i_1
       (.I0(x[6]),
        .I1(x[4]),
        .I2(x[9]),
        .O(x_color__0_carry__0_i_1_n_0));
  LUT3 #(
    .INIT(8'hD4)) 
    x_color__0_carry__0_i_2
       (.I0(x[5]),
        .I1(x[3]),
        .I2(x[8]),
        .O(x_color__0_carry__0_i_2_n_0));
  LUT3 #(
    .INIT(8'hD4)) 
    x_color__0_carry__0_i_3
       (.I0(x[4]),
        .I1(x[2]),
        .I2(x[7]),
        .O(x_color__0_carry__0_i_3_n_0));
  LUT3 #(
    .INIT(8'hD4)) 
    x_color__0_carry__0_i_4
       (.I0(x[3]),
        .I1(x[1]),
        .I2(x[6]),
        .O(x_color__0_carry__0_i_4_n_0));
  LUT6 #(
    .INIT(64'h8E71718E718E8E71)) 
    x_color__0_carry__0_i_5
       (.I0(x[9]),
        .I1(x[4]),
        .I2(x[6]),
        .I3(x[5]),
        .I4(x[7]),
        .I5(x[10]),
        .O(x_color__0_carry__0_i_5_n_0));
  LUT6 #(
    .INIT(64'h8E71718E718E8E71)) 
    x_color__0_carry__0_i_6
       (.I0(x[8]),
        .I1(x[3]),
        .I2(x[5]),
        .I3(x[4]),
        .I4(x[6]),
        .I5(x[9]),
        .O(x_color__0_carry__0_i_6_n_0));
  LUT6 #(
    .INIT(64'h8E71718E718E8E71)) 
    x_color__0_carry__0_i_7
       (.I0(x[7]),
        .I1(x[2]),
        .I2(x[4]),
        .I3(x[3]),
        .I4(x[5]),
        .I5(x[8]),
        .O(x_color__0_carry__0_i_7_n_0));
  LUT6 #(
    .INIT(64'h8E71718E718E8E71)) 
    x_color__0_carry__0_i_8
       (.I0(x[6]),
        .I1(x[1]),
        .I2(x[3]),
        .I3(x[2]),
        .I4(x[4]),
        .I5(x[7]),
        .O(x_color__0_carry__0_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 x_color__0_carry__1
       (.CI(x_color__0_carry__0_n_0),
        .CO({x_color__0_carry__1_n_0,x_color__0_carry__1_n_1,x_color__0_carry__1_n_2,x_color__0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({x_color__0_carry__1_i_1_n_0,x_color__0_carry__1_i_2_n_0,x_color__0_carry__1_i_3_n_0,x_color__0_carry__1_i_4_n_0}),
        .O({x_color__0_carry__1_n_4,x_color__0_carry__1_n_5,x_color__0_carry__1_n_6,x_color__0_carry__1_n_7}),
        .S({x_color__0_carry__1_i_5_n_0,x_color__0_carry__1_i_6_n_0,x_color__0_carry__1_i_7_n_0,x_color__0_carry__1_i_8_n_0}));
  LUT2 #(
    .INIT(4'h2)) 
    x_color__0_carry__1_i_1
       (.I0(x[8]),
        .I1(x[10]),
        .O(x_color__0_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    x_color__0_carry__1_i_2
       (.I0(x[7]),
        .I1(x[9]),
        .O(x_color__0_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    x_color__0_carry__1_i_3
       (.I0(x[6]),
        .I1(x[8]),
        .O(x_color__0_carry__1_i_3_n_0));
  LUT3 #(
    .INIT(8'hD4)) 
    x_color__0_carry__1_i_4
       (.I0(x[7]),
        .I1(x[5]),
        .I2(x[10]),
        .O(x_color__0_carry__1_i_4_n_0));
  LUT3 #(
    .INIT(8'h4B)) 
    x_color__0_carry__1_i_5
       (.I0(x[10]),
        .I1(x[8]),
        .I2(x[9]),
        .O(x_color__0_carry__1_i_5_n_0));
  LUT4 #(
    .INIT(16'hB44B)) 
    x_color__0_carry__1_i_6
       (.I0(x[9]),
        .I1(x[7]),
        .I2(x[10]),
        .I3(x[8]),
        .O(x_color__0_carry__1_i_6_n_0));
  LUT4 #(
    .INIT(16'hB44B)) 
    x_color__0_carry__1_i_7
       (.I0(x[8]),
        .I1(x[6]),
        .I2(x[9]),
        .I3(x[7]),
        .O(x_color__0_carry__1_i_7_n_0));
  LUT5 #(
    .INIT(32'h718E8E71)) 
    x_color__0_carry__1_i_8
       (.I0(x[10]),
        .I1(x[5]),
        .I2(x[7]),
        .I3(x[8]),
        .I4(x[6]),
        .O(x_color__0_carry__1_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 x_color__0_carry__2
       (.CI(x_color__0_carry__1_n_0),
        .CO(NLW_x_color__0_carry__2_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_x_color__0_carry__2_O_UNCONNECTED[3:1],x_color__0_carry__2_n_7}),
        .S({1'b0,1'b0,1'b0,x_color__0_carry__2_i_1_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    x_color__0_carry__2_i_1
       (.I0(x[9]),
        .I1(x[10]),
        .O(x_color__0_carry__2_i_1_n_0));
  LUT3 #(
    .INIT(8'hD4)) 
    x_color__0_carry_i_1
       (.I0(x[2]),
        .I1(x[0]),
        .I2(x[5]),
        .O(x_color__0_carry_i_1_n_0));
  LUT3 #(
    .INIT(8'h69)) 
    x_color__0_carry_i_2
       (.I0(x[0]),
        .I1(x[2]),
        .I2(x[5]),
        .O(x_color__0_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    x_color__0_carry_i_3
       (.I0(x[3]),
        .I1(x[0]),
        .O(x_color__0_carry_i_3_n_0));
  LUT6 #(
    .INIT(64'h8E71718E718E8E71)) 
    x_color__0_carry_i_4
       (.I0(x[5]),
        .I1(x[0]),
        .I2(x[2]),
        .I3(x[1]),
        .I4(x[3]),
        .I5(x[6]),
        .O(x_color__0_carry_i_4_n_0));
  LUT5 #(
    .INIT(32'h69966969)) 
    x_color__0_carry_i_5
       (.I0(x[0]),
        .I1(x[2]),
        .I2(x[5]),
        .I3(x[1]),
        .I4(x[4]),
        .O(x_color__0_carry_i_5_n_0));
  LUT4 #(
    .INIT(16'h2DD2)) 
    x_color__0_carry_i_6
       (.I0(x[0]),
        .I1(x[3]),
        .I2(x[1]),
        .I3(x[4]),
        .O(x_color__0_carry_i_6_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    x_color__0_carry_i_7
       (.I0(x[3]),
        .I1(x[0]),
        .O(x_color__0_carry_i_7_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 x_color__29_carry
       (.CI(1'b0),
        .CO({x_color__29_carry_n_0,x_color__29_carry_n_1,x_color__29_carry_n_2,x_color__29_carry_n_3}),
        .CYINIT(1'b0),
        .DI({x_color__29_carry_i_1_n_0,x_color__29_carry_i_2_n_0,x_color__29_carry_i_3_n_0,1'b0}),
        .O(NLW_x_color__29_carry_O_UNCONNECTED[3:0]),
        .S({x_color__29_carry_i_4_n_0,x_color__29_carry_i_5_n_0,x_color__29_carry_i_6_n_0,x_color__29_carry_i_7_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 x_color__29_carry__0
       (.CI(x_color__29_carry_n_0),
        .CO({NLW_x_color__29_carry__0_CO_UNCONNECTED[3],x_color__29_carry__0_n_1,x_color__29_carry__0_n_2,x_color__29_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,x_color__29_carry__0_i_1_n_0,x_color__29_carry__0_i_2_n_0,x_color__29_carry__0_i_3_n_0}),
        .O(NLW_x_color__29_carry__0_O_UNCONNECTED[3:0]),
        .S({1'b0,x_color__29_carry__0_i_4_n_0,x_color__29_carry__0_i_5_n_0,x_color__29_carry__0_i_6_n_0}));
  LUT6 #(
    .INIT(64'h000000004642626A)) 
    x_color__29_carry__0_i_1
       (.I0(x_color__0_carry__1_n_4),
        .I1(x_color__0_carry__1_n_5),
        .I2(x_color__0_carry__2_n_7),
        .I3(x_color__0_carry__1_n_7),
        .I4(x_color__0_carry__1_n_6),
        .I5(x[9]),
        .O(x_color__29_carry__0_i_1_n_0));
  LUT6 #(
    .INIT(64'h000000009AA69666)) 
    x_color__29_carry__0_i_2
       (.I0(x_color__0_carry__2_n_7),
        .I1(x_color__0_carry__1_n_5),
        .I2(x_color__0_carry__1_n_6),
        .I3(x_color__0_carry__1_n_4),
        .I4(x_color__0_carry__1_n_7),
        .I5(x[8]),
        .O(x_color__29_carry__0_i_2_n_0));
  LUT5 #(
    .INIT(32'h00009666)) 
    x_color__29_carry__0_i_3
       (.I0(x_color__0_carry__1_n_4),
        .I1(x_color__0_carry__1_n_6),
        .I2(x_color__0_carry__1_n_7),
        .I3(x_color__0_carry__1_n_5),
        .I4(x[7]),
        .O(x_color__29_carry__0_i_3_n_0));
  LUT6 #(
    .INIT(64'h02ABD540FD542ABF)) 
    x_color__29_carry__0_i_4
       (.I0(x[9]),
        .I1(x_color__0_carry__1_n_5),
        .I2(x_color__29_carry__0_i_7_n_0),
        .I3(x_color__0_carry__1_n_4),
        .I4(x_color__0_carry__2_n_7),
        .I5(x[10]),
        .O(x_color__29_carry__0_i_4_n_0));
  LUT6 #(
    .INIT(64'h422BBDD4BDD4422B)) 
    x_color__29_carry__0_i_5
       (.I0(x[8]),
        .I1(x_color__29_carry__0_i_7_n_0),
        .I2(x_color__0_carry__2_n_7),
        .I3(x_color__0_carry__1_n_5),
        .I4(x_color__0_carry__1_n_4),
        .I5(x[9]),
        .O(x_color__29_carry__0_i_5_n_0));
  LUT5 #(
    .INIT(32'h69969669)) 
    x_color__29_carry__0_i_6
       (.I0(x_color__29_carry__0_i_3_n_0),
        .I1(x_color__29_carry__0_i_7_n_0),
        .I2(x_color__0_carry__1_n_5),
        .I3(x_color__0_carry__2_n_7),
        .I4(x[8]),
        .O(x_color__29_carry__0_i_6_n_0));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hE888)) 
    x_color__29_carry__0_i_7
       (.I0(x_color__0_carry__1_n_6),
        .I1(x_color__0_carry__1_n_4),
        .I2(x_color__0_carry__1_n_5),
        .I3(x_color__0_carry__1_n_7),
        .O(x_color__29_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h6F)) 
    x_color__29_carry_i_1
       (.I0(x_color__0_carry__1_n_7),
        .I1(x_color__0_carry__1_n_5),
        .I2(x[6]),
        .O(x_color__29_carry_i_1_n_0));
  (* HLUTNM = "lutpair0" *) 
  LUT2 #(
    .INIT(4'h2)) 
    x_color__29_carry_i_2
       (.I0(x_color__0_carry__1_n_6),
        .I1(x[5]),
        .O(x_color__29_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    x_color__29_carry_i_3
       (.I0(x_color__0_carry__1_n_7),
        .I1(x[4]),
        .O(x_color__29_carry_i_3_n_0));
  LUT6 #(
    .INIT(64'hBD4242BD42BDBD42)) 
    x_color__29_carry_i_4
       (.I0(x[6]),
        .I1(x_color__0_carry__1_n_5),
        .I2(x_color__0_carry__1_n_7),
        .I3(x_color__0_carry__1_n_6),
        .I4(x_color__0_carry__1_n_4),
        .I5(x[7]),
        .O(x_color__29_carry_i_4_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    x_color__29_carry_i_5
       (.I0(x_color__29_carry_i_2_n_0),
        .I1(x_color__0_carry__1_n_5),
        .I2(x_color__0_carry__1_n_7),
        .I3(x[6]),
        .O(x_color__29_carry_i_5_n_0));
  (* HLUTNM = "lutpair0" *) 
  LUT4 #(
    .INIT(16'h6696)) 
    x_color__29_carry_i_6
       (.I0(x_color__0_carry__1_n_6),
        .I1(x[5]),
        .I2(x[4]),
        .I3(x_color__0_carry__1_n_7),
        .O(x_color__29_carry_i_6_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    x_color__29_carry_i_7
       (.I0(x[4]),
        .I1(x_color__0_carry__1_n_7),
        .O(x_color__29_carry_i_7_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
