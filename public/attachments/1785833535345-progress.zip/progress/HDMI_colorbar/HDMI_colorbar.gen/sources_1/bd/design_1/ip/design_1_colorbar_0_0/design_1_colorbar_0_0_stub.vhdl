-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Aug  4 16:07:14 2026
-- Host        : DVSY-62334655 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/DVSY_62334655/Documents/vivado/001_projects/HDMI_colorbar/HDMI_colorbar.gen/sources_1/bd/design_1/ip/design_1_colorbar_0_0/design_1_colorbar_0_0_stub.vhdl
-- Design      : design_1_colorbar_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z010clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity design_1_colorbar_0_0 is
  Port ( 
    x : in STD_LOGIC_VECTOR ( 10 downto 0 );
    y : in STD_LOGIC_VECTOR ( 9 downto 0 );
    active_video : in STD_LOGIC;
    rgb : out STD_LOGIC_VECTOR ( 23 downto 0 )
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_colorbar_0_0 : entity is "design_1_colorbar_0_0,colorbar,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of design_1_colorbar_0_0 : entity is "design_1_colorbar_0_0,colorbar,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=colorbar,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_1_colorbar_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_1_colorbar_0_0 : entity is "module_ref";
end design_1_colorbar_0_0;

architecture stub of design_1_colorbar_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "x[10:0],y[9:0],active_video,rgb[23:0]";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "colorbar,Vivado 2025.2";
begin
end;
