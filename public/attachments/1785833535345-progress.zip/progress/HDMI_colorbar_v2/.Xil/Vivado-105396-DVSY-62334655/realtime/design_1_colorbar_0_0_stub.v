// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "design_1_colorbar_0_0,colorbar,{}" *) (* CORE_GENERATION_INFO = "design_1_colorbar_0_0,colorbar,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=colorbar,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,h_active=640,v_active=480}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "colorbar,Vivado 2025.2" *) 
module design_1_colorbar_0_0(active_video, pos_x, pos_y, rgb);
  input active_video;
  input [9:0]pos_x;
  input [8:0]pos_y;
  output [23:0]rgb;
endmodule
