# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "h_active" -parent ${Page_0}
  ipgui::add_param $IPINST -name "v_active" -parent ${Page_0}


}

proc update_PARAM_VALUE.h_active { PARAM_VALUE.h_active } {
	# Procedure called to update h_active when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.h_active { PARAM_VALUE.h_active } {
	# Procedure called to validate h_active
	return true
}

proc update_PARAM_VALUE.v_active { PARAM_VALUE.v_active } {
	# Procedure called to update v_active when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.v_active { PARAM_VALUE.v_active } {
	# Procedure called to validate v_active
	return true
}


proc update_MODELPARAM_VALUE.h_active { MODELPARAM_VALUE.h_active PARAM_VALUE.h_active } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.h_active}] ${MODELPARAM_VALUE.h_active}
}

proc update_MODELPARAM_VALUE.v_active { MODELPARAM_VALUE.v_active PARAM_VALUE.v_active } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.v_active}] ${MODELPARAM_VALUE.v_active}
}

