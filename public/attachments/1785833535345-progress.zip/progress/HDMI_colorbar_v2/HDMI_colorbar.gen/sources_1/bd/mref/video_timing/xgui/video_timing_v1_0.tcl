# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "x_back" -parent ${Page_0}
  ipgui::add_param $IPINST -name "x_front" -parent ${Page_0}
  ipgui::add_param $IPINST -name "x_pixels" -parent ${Page_0}
  ipgui::add_param $IPINST -name "x_sync" -parent ${Page_0}
  ipgui::add_param $IPINST -name "x_total" -parent ${Page_0}
  ipgui::add_param $IPINST -name "y_back" -parent ${Page_0}
  ipgui::add_param $IPINST -name "y_front" -parent ${Page_0}
  ipgui::add_param $IPINST -name "y_pixels" -parent ${Page_0}
  ipgui::add_param $IPINST -name "y_sync" -parent ${Page_0}
  ipgui::add_param $IPINST -name "y_total" -parent ${Page_0}


}

proc update_PARAM_VALUE.x_back { PARAM_VALUE.x_back } {
	# Procedure called to update x_back when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.x_back { PARAM_VALUE.x_back } {
	# Procedure called to validate x_back
	return true
}

proc update_PARAM_VALUE.x_front { PARAM_VALUE.x_front } {
	# Procedure called to update x_front when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.x_front { PARAM_VALUE.x_front } {
	# Procedure called to validate x_front
	return true
}

proc update_PARAM_VALUE.x_pixels { PARAM_VALUE.x_pixels } {
	# Procedure called to update x_pixels when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.x_pixels { PARAM_VALUE.x_pixels } {
	# Procedure called to validate x_pixels
	return true
}

proc update_PARAM_VALUE.x_sync { PARAM_VALUE.x_sync } {
	# Procedure called to update x_sync when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.x_sync { PARAM_VALUE.x_sync } {
	# Procedure called to validate x_sync
	return true
}

proc update_PARAM_VALUE.x_total { PARAM_VALUE.x_total } {
	# Procedure called to update x_total when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.x_total { PARAM_VALUE.x_total } {
	# Procedure called to validate x_total
	return true
}

proc update_PARAM_VALUE.y_back { PARAM_VALUE.y_back } {
	# Procedure called to update y_back when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.y_back { PARAM_VALUE.y_back } {
	# Procedure called to validate y_back
	return true
}

proc update_PARAM_VALUE.y_front { PARAM_VALUE.y_front } {
	# Procedure called to update y_front when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.y_front { PARAM_VALUE.y_front } {
	# Procedure called to validate y_front
	return true
}

proc update_PARAM_VALUE.y_pixels { PARAM_VALUE.y_pixels } {
	# Procedure called to update y_pixels when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.y_pixels { PARAM_VALUE.y_pixels } {
	# Procedure called to validate y_pixels
	return true
}

proc update_PARAM_VALUE.y_sync { PARAM_VALUE.y_sync } {
	# Procedure called to update y_sync when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.y_sync { PARAM_VALUE.y_sync } {
	# Procedure called to validate y_sync
	return true
}

proc update_PARAM_VALUE.y_total { PARAM_VALUE.y_total } {
	# Procedure called to update y_total when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.y_total { PARAM_VALUE.y_total } {
	# Procedure called to validate y_total
	return true
}


proc update_MODELPARAM_VALUE.x_pixels { MODELPARAM_VALUE.x_pixels PARAM_VALUE.x_pixels } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.x_pixels}] ${MODELPARAM_VALUE.x_pixels}
}

proc update_MODELPARAM_VALUE.x_front { MODELPARAM_VALUE.x_front PARAM_VALUE.x_front } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.x_front}] ${MODELPARAM_VALUE.x_front}
}

proc update_MODELPARAM_VALUE.x_sync { MODELPARAM_VALUE.x_sync PARAM_VALUE.x_sync } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.x_sync}] ${MODELPARAM_VALUE.x_sync}
}

proc update_MODELPARAM_VALUE.x_back { MODELPARAM_VALUE.x_back PARAM_VALUE.x_back } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.x_back}] ${MODELPARAM_VALUE.x_back}
}

proc update_MODELPARAM_VALUE.y_pixels { MODELPARAM_VALUE.y_pixels PARAM_VALUE.y_pixels } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.y_pixels}] ${MODELPARAM_VALUE.y_pixels}
}

proc update_MODELPARAM_VALUE.y_front { MODELPARAM_VALUE.y_front PARAM_VALUE.y_front } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.y_front}] ${MODELPARAM_VALUE.y_front}
}

proc update_MODELPARAM_VALUE.y_sync { MODELPARAM_VALUE.y_sync PARAM_VALUE.y_sync } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.y_sync}] ${MODELPARAM_VALUE.y_sync}
}

proc update_MODELPARAM_VALUE.y_back { MODELPARAM_VALUE.y_back PARAM_VALUE.y_back } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.y_back}] ${MODELPARAM_VALUE.y_back}
}

proc update_MODELPARAM_VALUE.y_total { MODELPARAM_VALUE.y_total PARAM_VALUE.y_total } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.y_total}] ${MODELPARAM_VALUE.y_total}
}

proc update_MODELPARAM_VALUE.x_total { MODELPARAM_VALUE.x_total PARAM_VALUE.x_total } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.x_total}] ${MODELPARAM_VALUE.x_total}
}

