//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Tue Aug  4 17:42:01 2026
//Host        : DVSY-62334655 running 64-bit major release  (build 9200)
//Command     : generate_target design_1.bd
//Design      : design_1
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "design_1,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design_1,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=4,numReposBlks=4,numNonXlnxBlks=1,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=2,numPkgbdBlks=0,bdsource=USER,da_board_cnt=5,da_clkrst_cnt=2,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "design_1.hwdef" *) 
module design_1
   (TMDS_0_clk_n,
    TMDS_0_clk_p,
    TMDS_0_data_n,
    TMDS_0_data_p,
    led1_0,
    led2_0,
    led3_0,
    reset_rtl,
    sys_clock);
  (* X_INTERFACE_INFO = "digilentinc.com:interface:tmds:1.0 TMDS_0 CLK_N" *) (* X_INTERFACE_MODE = "Master" *) output TMDS_0_clk_n;
  (* X_INTERFACE_INFO = "digilentinc.com:interface:tmds:1.0 TMDS_0 CLK_P" *) output TMDS_0_clk_p;
  (* X_INTERFACE_INFO = "digilentinc.com:interface:tmds:1.0 TMDS_0 DATA_N" *) output [2:0]TMDS_0_data_n;
  (* X_INTERFACE_INFO = "digilentinc.com:interface:tmds:1.0 TMDS_0 DATA_P" *) output [2:0]TMDS_0_data_p;
  output led1_0;
  output led2_0;
  output led3_0;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.RESET_RTL RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.RESET_RTL, INSERT_VIP 0, POLARITY ACTIVE_HIGH" *) input reset_rtl;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.SYS_CLOCK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.SYS_CLOCK, CLK_DOMAIN design_1_sys_clock, FREQ_HZ 125000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input sys_clock;

  wire TMDS_0_clk_n;
  wire TMDS_0_clk_p;
  wire [2:0]TMDS_0_data_n;
  wire [2:0]TMDS_0_data_p;
  wire clk_wiz_0_clk_out1;
  wire clk_wiz_0_clk_out2;
  wire [23:0]colorbar_0_rgb;
  wire led1_0;
  wire led2_0;
  wire led3_0;
  wire reset_rtl;
  wire sys_clock;
  wire video_timing_0_active_video;
  wire video_timing_0_hsync;
  wire [9:0]video_timing_0_pos_x;
  wire [8:0]video_timing_0_pos_y;
  wire video_timing_0_vsync;

  design_1_clk_wiz_0_0 clk_wiz_0
       (.clk_in1(sys_clock),
        .clk_out1(clk_wiz_0_clk_out1),
        .clk_out2(clk_wiz_0_clk_out2),
        .reset(reset_rtl));
  design_1_colorbar_0_0 colorbar_0
       (.active_video(video_timing_0_active_video),
        .pos_x(video_timing_0_pos_x),
        .pos_y(video_timing_0_pos_y),
        .rgb(colorbar_0_rgb));
  design_1_rgb2dvi_0_0 rgb2dvi_0
       (.PixelClk(clk_wiz_0_clk_out1),
        .SerialClk(clk_wiz_0_clk_out2),
        .TMDS_Clk_n(TMDS_0_clk_n),
        .TMDS_Clk_p(TMDS_0_clk_p),
        .TMDS_Data_n(TMDS_0_data_n),
        .TMDS_Data_p(TMDS_0_data_p),
        .aRst(reset_rtl),
        .vid_pData(colorbar_0_rgb),
        .vid_pHSync(video_timing_0_hsync),
        .vid_pVDE(video_timing_0_active_video),
        .vid_pVSync(video_timing_0_vsync));
  design_1_video_timing_0_0 video_timing_0
       (.active_video(video_timing_0_active_video),
        .clk(clk_wiz_0_clk_out1),
        .hsync(video_timing_0_hsync),
        .led1(led1_0),
        .led2(led2_0),
        .led3(led3_0),
        .pos_x(video_timing_0_pos_x),
        .pos_y(video_timing_0_pos_y),
        .rst(reset_rtl),
        .vsync(video_timing_0_vsync));
endmodule
