#include "invert.h"

void apply_color_invert(u32 *frame_ptr, int width, int height) {
    int total_pixels = width * height;
    
    for (int i = 0; i < total_pixels; i++) {
        u32 pixel = frame_ptr[i];
        
        unsigned char r = (pixel >> 16) & 0xFF;
        unsigned char g = (pixel >> 8) & 0xFF;
        unsigned char b = pixel & 0xFF;
        
        unsigned char new_r = 255 - r;
        unsigned char new_g = 255 - g;
        unsigned char new_b = 255 - b;
        
        frame_ptr[i] = (new_r << 16) | (new_g << 8) | new_b;
    }
}