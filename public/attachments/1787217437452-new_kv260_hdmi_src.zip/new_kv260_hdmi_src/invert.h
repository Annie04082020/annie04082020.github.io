#ifndef INVERT_H
#define INVERT_H

#include "xil_types.h"

void apply_color_invert(u32 *frame_ptr, int width, int height);

#endif