#include "platform.h"
#include "xil_printf.h"
#include "displayport.h"
#include "vtc.h"
#include "imx219.h"
#include "mipi.h"
#include "xil_exception.h"
#include "demosaic.h"
#include "invert.h"
#include "uart_control.h"
// #include "tpg.h"
#include "vdma.h"
#include "gamma_lut.h"
#include "parameters.h"
#include "xilinx-gamma-coeff.h"

#include "xstatus.h"

int main() {
	int Status;
    init_platform();

    xil_printf("Starting...\r\n");
//    displayport_init();
//    displayport_setup_interrupts();
//    vtc_init();

	// tpg_init();

//  vdma_init();
//	gamma_lut_init(xgamma10_06, xgamma10_14, xgamma10_07);
//	demosaic_init();
//	mipi_init();
//	imx219_init();

	init_uart();

	Status = init_uart0();

	if (Status != XST_SUCCESS) {
	    xil_printf("UART0 init failed\r\n");
	}
	else {
		xil_printf("UART0 init OK\r\n");
	    uart0_send("UART0 TEST\r\n");
	}

	xil_printf("Entire video pipeline activated\r\n");
	while(1){
		uart0_send("UART0 TEST\r\n");
//		XUartPs_SendByte(
//		        XPAR_XUARTPS_0_BASEADDR,
//		        'U'
//		    );
		for (volatile int i = 0; i < 50; i++);
	}
//	u8 new_mode = 255;
//	u8 current_mode = 0;
//	u32 *frame_ptr = (u32 *)VDMA_BUFFER_ADDR;

//	while(1){
//		new_mode = uart_get_mode();
////		xil_printf("new_mode = %d\n\r",new_mode);
//		if((new_mode != 255) && (new_mode != current_mode)){
//			xil_printf("In change mode \n\r");
//			xil_printf("new_mode = %d\n\r",new_mode);
//			current_mode = new_mode;
////			xil_printf("%d,%d\r\n",new_mode,current_mode);
////			xil_printf("new_mode = %d\r\n", new_mode);
//		}
//	}
	cleanup_platform();
    return 0;
}
