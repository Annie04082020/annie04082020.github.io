#ifndef SRC_PARAMETERS_H_
#define SRC_PARAMETERS_H_

#define ULTRA96 0
#define KV260   1

#define BOARD			KV260 // set to ULTRA96 or KV260

#define VIDEO_COLUMNS	1920
#define VIDEO_ROWS		1080

#endif /* SRC_PARAMETERS_H_ */
