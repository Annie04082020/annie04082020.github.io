#ifndef __PLATFORM_H_
#define __PLATFORM_H_

#include "platform_config.h"
#include "xil_types.h"

void init_platform();
void cleanup_platform();
void init_uart(void);

int init_uart0(void);
void uart0_send(const char *data);

#endif
