#define UART XPAR_XUARTPS_0_BASEADDR

#include "xparameters.h"
#include "xil_printf.h"
#include "xuartps_hw.h"
#include "uart_control.h"
#include "xuartps.h"

u8 uart_get_mode(void)
{
    // xil_printf("UART ready\r\n");
    u8 ch;
    u8 mode;
    if(XUartPs_IsReceiveData(UART)){
        ch = XUartPs_RecvByte(UART);
        if(ch>=48 && ch<=57){
            mode = ch-48;
            return mode;
        }
    }
    return 255;
}

