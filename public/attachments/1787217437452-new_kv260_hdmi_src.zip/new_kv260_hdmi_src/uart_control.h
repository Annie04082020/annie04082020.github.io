#ifndef SRC_UART_CONTROL_H_
#define SRC_UART_CONTROL_H_

u8 uart_get_mode(void);

#endif /* SRC_UART_CONTROL_H_ */